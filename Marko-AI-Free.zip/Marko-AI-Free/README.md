# Marko AI — kostenlose Cloudflare-Variante

Diese Version korrigiert außerdem die absoluten Asset-Pfade (`/styles.css`, `/app.js`), die unter GitHub Pages mit einem Repository-Unterpfad das Design brechen können.

## Wichtig
- GitHub Pages hostet nur die statischen Dateien. Diese Variante benötigt Cloudflare Workers als API, D1 als Datenbank und Workers AI.
- Cloudflare hat kostenlose Kontingente, aber Limits und Bedingungen können sich ändern. Workers AI ist nicht unbegrenzt kostenlos.
- Die Bildschirm-Freigabe kann in diesem UI einen Screenshot erfassen. Das aktuelle Beispiel nutzt ein Textmodell; die Bildanalyse ist noch nicht in diesem Worker verdrahtet. Screen AI Textfragen funktionieren, Bildanalyse benötigt ein visionfähiges Modell und separate Implementierung.
- Diese Vorlage ist ein Startprojekt und sollte vor öffentlicher Nutzung weiter abgesichert/getestet werden.

## Einmalige Einrichtung

1. Erstelle ein Cloudflare-Konto: https://dash.cloudflare.com/
2. Installiere Node.js LTS: https://nodejs.org/ und Git (optional).
3. Installiere Wrangler im Terminal:
   ```bash
   npm install -g wrangler
   wrangler login
   ```
4. Im Ordner dieses Projekts eine D1-Datenbank erstellen:
   ```bash
   wrangler d1 create marko-db
   ```
5. Kopiere die `database_id` aus der Ausgabe in `wrangler.toml` anstelle von `REPLACE_WITH_D1_DATABASE_ID`.
6. Erstelle Tabellen:
   ```bash
   wrangler d1 migrations apply marko-db --remote
   ```
7. Setze geheime Werte (nutze jeweils lange, eigene zufällige Werte):
   ```bash
   wrangler secret put SETUP_TOKEN
   wrangler secret put SESSION_SECRET
   ```
   Bei jeder Abfrage den jeweiligen Wert eingeben. Merke dir `SETUP_TOKEN`, er wird für die Erst-Einrichtung gebraucht.
8. Deploye:
   ```bash
   wrangler deploy
   ```
9. Öffne die `workers.dev`-Adresse, die Wrangler ausgibt. Gib den `SETUP_TOKEN` in Markos Setup ein und lade die Zugangsdaten-Datei herunter.

## GitHub

Du kannst diesen Ordner als Repository hochladen. Nicht hochladen: geheime Tokens oder private Zugangsdaten. `wrangler.toml` muss deine echte D1-ID enthalten. Der Worker ist die Laufzeit; GitHub Pages allein betreibt keine API.

## Lokaler Design-Fix für deine bestehende GitHub-Pages-Seite

In `public/index.html` werden CSS und JavaScript relativ geladen (`./styles.css` und `./app.js`). Das ist nötig für eine URL wie `https://USERNAME.github.io/Markos/`. Kopiere diese zwei Änderungen auch in dein bisheriges Repository, wenn du dort nur das Design reparieren willst.
